function [  ] = Training( I, C, Range)
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here
I=double(I);
X1=C(:,1);
topLeftx=X1(1);
topLefty=X1(2);
X2=C(:,2);
X3=C(:,3);
X4=C(:,4);

MIN=Range(1,1);
MAX=Range(2,1);

Rx = zeros(1,100);
Ry = zeros(1,100);
for i=1:10
    for j=1:10
        Rx(1,(i-1)*10+j) = topLeftx + (i-1)*10;
        Ry(1,(i-1)*10+j) =topLefty + (j-1)*10;
    end
end

plot(Rx',Ry','b*');
N=1 ;

R = [Rx;Ry;ones(1,100)];

for i=1:N
    rand = randi([MIN MAX],size(C));
    CNew=C+rand ;
    CHomo=[C;ones(1,size(C,2))];
    CNewHomo =[CNew;ones(1,size(CNew,2))]; 
    H=homography2d(CHomo, CNewHomo);
       
    Rt=H\R;
    
    
    movingPoints = CNew';
    fixedPoints = C';
    tform=fitgeotrans(movingPoints,fixedPoints,'projective')
    
    %maketform('affine',[u v],[x y])
%tform = affine2d([1 0 0; .5 1 0; 0 0 1])
    %tform=projective2d(H);
    INew=imwarp(I,tform) ;
    figure;
    imagesc(INew);

end


end

