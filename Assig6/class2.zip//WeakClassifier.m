classdef WeakClassifier
    %WEAKCLASSIFIER Summary of this class goes here
    %   Detailed explanation goes here
    
    properties
        dimension;
        parity;
        threshold;
        
    end
    
    methods
        function obj=WeakClassifier()
        end
        
        function obj=train(samples,label,weight)
            error = 0.5;
            while(error>=0.5)
            this.d
                
            end
            
            
            
            obj=error;
        end
        
        function obj=test(data)
        end
        
    end
    
end

